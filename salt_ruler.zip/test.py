#!/usr/bin/env python
#coding:utf-8
import os

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "SaltRuler.settings")

from assetmanage.models import Blog,Assetmanage
def main():
    f = open('importserver.txt')

    List = []
    for line in f:
        values = line.split(',')
        List.append(Assetmanage(asset_num=values[0] , type=values[1]  , server_ip=values[2]  , remote_ip=values[3]  , data_center=values[4]  , room_num=values[5]  , rack_num=values[6]  , system_type=values[7]  , cputype_num=values[8]  , disksize_num=values[9]  , memsize_num= values[10] , disk_raid=values[11]  , card_type_num=values[12]  , power_num=values[13]  , service_num=values[14]  , buy_time=values[15]  , expiration_time=values[16]  , note=values[17]))
    f.close()

    # 以上四行 也可以用 列表解析 写成下面这样
    # BlogList = [Blog(title=line.split('****')[0], content=line.split('****')[1]) for line in f]

    Assetmanage.objects.bulk_create(List)


if __name__ == "__main__":
    main()
    print('Done!')